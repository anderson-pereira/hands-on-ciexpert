# Backup: Subsistema SPI Peripheral In-Frame com Burst e CDC Mailbox

Este pacote preserva a implementação original do subsistema **SPI Peripheral + CDC Bridge + CSR Bank** desenvolvida antes do recebimento do documento `DV_BlockGuide_MiniSoCAES_v1.0.0.pdf`.

## Quando reutilizar esta implementação
Esta arquitetura implementa o **padrão industrial SPI In-Frame com suporte a Burst (auto-incremento)**, amplamente utilizado em sensores MEMS (ex.: Bosch BMI270), memórias SPI e periféricos de controle orientados a bytes:
- **SPI Mode 0** (`CPOL = 0`, `CPHA = 0`), MSB-first, `CS_n` ativo em nível baixo e controle de buffer tri-state (`poci_oe`).
- **Enquadramento orientado a bytes (8 bits):**
  - `CMD = {R/W, ADDR[6:0]}` (`bit 7 = 0` para escrita, `1` para leitura).
  - **Escrita (Single ou Burst):** `CMD` seguido de `1..N` bytes de dados com auto-incremento automático de endereço.
  - **Leitura (Single ou Burst com Turnaround):** `CMD` + `1 Dummy Byte` + `1..N` bytes de dados com *prefetch* em pipeline entre domínios de clock.
- **CDC Robusto parametrizado por tipos (`spi_cdc_mailbox.sv`):** Handshake de toggle de 4 fases com *Data-Hold* e sincronizadores 2-FF, encapsulado com `interface` e `modport` SystemVerilog.

## Conteúdo do Pacote

```text
spi_inframe_burst_backup/
├── README.md                          # Guia geral deste pacote de backup
├── docs/
│   ├── README_SPI.md                  # Especificação detalhada, mapa CSR e limitações de timing
│   └── spi_aes_top_schematic.drawio   # Esquemático em blocos (Draw.io)
├── rtl/
│   ├── spi_pkg.sv                     # Tipos empacotados (structs CDC), estados FSM e endereços CSR
│   ├── spi_if.sv                      # Interfaces SystemVerilog (spi_phy_if, spi_csr_if, mailbox)
│   ├── spi_peripheral_phy.sv          # Camada física serial no domínio SCLK com prefetch
│   ├── spi_cdc_mailbox.sv             # Ponte CDC assíncrona genérica por toggle de 4 fases
│   ├── spi_csr_bank.sv                # Banco de registradores CSR de 8 bits no domínio sys_clk
│   └── spi_aes_top.sv                 # Top-level integrador do subsistema SPI
└── tb/
    └── tb_spi_aes_top.sv              # Testbench auto-verificante (R/W, trava PLL, burst 16B e abort)
```

## Como Simular Isoladamente

### Synopsys VCS
```bash
vlogan -full64 -sverilog -timescale=1ns/1ps +lint=all \
    rtl/spi_pkg.sv rtl/spi_if.sv \
    rtl/spi_peripheral_phy.sv rtl/spi_cdc_mailbox.sv rtl/spi_csr_bank.sv rtl/spi_aes_top.sv \
    tb/tb_spi_aes_top.sv
vcs -full64 -timescale=1ns/1ps -top tb_spi_aes_top -o simv_spi
./simv_spi
```

### Icarus Verilog
```bash
iverilog -g2012 -s tb_spi_aes_top -o simv_spi \
    rtl/spi_pkg.sv rtl/spi_if.sv \
    rtl/spi_peripheral_phy.sv rtl/spi_cdc_mailbox.sv rtl/spi_csr_bank.sv rtl/spi_aes_top.sv \
    tb/tb_spi_aes_top.sv
vvp simv_spi
```

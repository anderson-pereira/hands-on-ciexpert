# SPI Peripheral + CSR + CDC (projeto hands-on AES)

Baseado no planejamento do projeto: SPI física em `sclk`, CSRs e interface AES em `sys_clk`, clocks assíncronos. **O PDF não especifica endereços, campos, valores de reset, frequências ou formato SPI**; os detalhes abaixo são escolhas didáticas.

## Protocolo adotado
- 4 fios, Mode 0, MSB-first, `CS_n` baixo, POCI Hi-Z fora da seleção.
- Sinais: `SCLK`, `CS_n`, `PICO` (Peripheral In, Controller Out) e `POCI` (Peripheral Out, Controller In).
- Comando `{R/W, ADDRESS[6:0]}`; bit 7 = 1 para leitura.
- Escrita: `CMD, DATA0, DATA1, ...`; leitura: `CMD, 1 byte dummy, DATA0, DATA1, ...`.
- Auto-incremento; ao alcançar `0x7F` o autoincremento para; bytes adicionais retornam zero/erro (sem wrap). Endereço `0x00` reservado: leitura 0, escrita ignorada (não é a regra do BMI270 real).
- Burst permitido somente se o handshake completar antes do próximo byte. Sem flow control nem FIFO. `spi_error` acusa perda de prazo/saturação do quadro, não é resposta no POCI.
- No primeiro read, a resposta tem de estar carregada até o fim do dummy. Nos bytes seguintes, o próximo dado precisa estar pronto antes do fim do byte atual.
- `CS_n` atua como reset assíncrono direto da PHY (`phy_rst_n = !cs_n`), descartando o estado de transação; requisições CDC já aceitas seguem seu fluxo natural. O reset global `rst_n` gerencia o restante do SoC (CDC, CSR, AES).

## Mapa de CSRs (Alinhado com a Arquitetura v1.0 e Planejamento)
| Endereço | Nome | Acesso | Comportamento |
|---|---|---|---|
| 0x00 | Reservado | -- | Leitura 0; escrita ignorada |
| 0x01 | AES_CTRL | RW/pulse | Bit 0 `aes_start_pulse` (auto-limpante), bits 7:1 retidos |
| 0x02 | AES_STATUS | RO | `{5'b0, aes_error, aes_done, aes_busy}` |
| 0x03 | AES_CONFIG | RW | Byte de configuração do núcleo AES |
| 0x04 | IRQ_STATUS | RO/W1C | Bit 0 done, bit 1 error; eventos sticky |
| 0x05 | BLOCK_LEN | RW | Quantidade de blocos de 128 bits a cifrar (padrão 0x01) |
| 0x06 | SRC_ADDR_L | RW | Endereço base de leitura da memória (LSB [7:0]) |
| 0x07 | SRC_ADDR_H | RW | Endereço base de leitura da memória (MSB [15:8]) |
| 0x08 | DST_ADDR_L | RW | Endereço base de escrita da memória (LSB [7:0]) |
| 0x09 | DST_ADDR_H | RW | Endereço base de escrita da memória (MSB [15:8]) |
| 0x10..0x1F | KEY_0..15 | RW | Chave criptográfica AES de 128 bits (16 bytes, suporte a burst) |
| 0x20 | PLL_CONFIG | RW | Configuração do PLL (escrita bloqueada se `!pll_locked`, conforme planejamento) |
| 0x21 | PLL_STATUS | RO | Bit 0 `pll_locked` |
| 0x30 | POWER_CTRL | RW | Controle de energia placeholder |
| 0x31 | POWER_STATUS | RO | Bits 1:0 estado de energia |

## Arquivos e Estrutura SystemVerilog
- `rtl/spi_pkg.sv`: Pacote contendo enumerações de estado da FSM (`spi_phy_state_e`), structs empacotadas de payload leve (`spi_wr_req_t` [15 bits], `spi_rd_req_t` [7 bits], `spi_rd_rsp_t` [8 bits]) e constantes de endereço CSR.
- `rtl/spi_if.sv`: Interfaces SystemVerilog com modports:
  - `spi_phy_if`: barramento físico SPI (`peripheral`/`controller`, sinais `pico`/`poci_o`/`poci_oe`).
  - `spi_mb_src_if`: canal de CDC no domínio `sclk` (`initiator`/`target`, `send`, `req`, `ready`, `done`, `rsp`).
  - `spi_mb_dst_if`: canal de CDC no domínio `sys_clk` (`initiator`/`target`, `valid`, `req`, `rsp`).
  - `spi_csr_if`: barramento síncrono CSR (`initiator`/`target`).
- `rtl/spi_peripheral_phy.sv`: Camada física em `sclk`, serialização/deserialização, prefetch em pipeline e descarte local pós-aborto (drain de 1 bit, sem overhead de tags), conectada via `spi_phy_if.peripheral`, `wr_mb` e `rd_mb` (`spi_mb_src_if.initiator`).
- `rtl/spi_cdc_mailbox.sv`: Ponte CDC por handshake de toggle parametrizada nativamente por tipos SystemVerilog (`type REQ_T`, `type RSP_T`), conectada via `spi_mb_src_if.target` e `spi_mb_dst_if.initiator`.
- `rtl/spi_csr_bank.sv`: Banco de registradores CSR em `sys_clk`, conectado via `spi_csr_if.target`.
- `rtl/spi_aes_top.sv`: Top-level integrador que instancia as interfaces e conecta os módulos via modports e structs tipadas.
- `tb/tb_spi_aes_top.sv`: Testbench dirigido com cobertura de escrita/leitura, proteção do PLL, burst de chave de 128 bits e prefetch.

## Limitações importantes
1. **Não há garantia automática de timing.** Dois estágios de sincronização + latência de requisição/resposta + clock phase e overhead do PHY precisam caber dentro de 8 clocks de `sclk` para a primeira leitura e dentro de 8 clocks para cada byte de burst. Verificar em simulação com clocks assíncronos e SDC/STA.
2. Para simplificar a didática, o exemplo usa um mailbox com payload mantido estável, sem FIFO. Não oferece controle de fluxo ao controller; o sistema deve garantir `sys_clk` funcionando e uma frequência `sclk` conservadora.
3. `spi_error` é uma indicação de depuração; leitura sem dado no prazo devolve `0x00`. Não trate esse comportamento como integridade de dados garantida.
4. A deassertiva de reset e os requisitos de reset/clock por domínio precisam ser adaptados às células/estrutura do projeto; `rst_n` gerencia os domínios internos e `CS_n` comanda o reset da PHY. Em integração ASIC recomenda-se analisar RDC.
5. Em caso de reconfiguração/interrupção de `sys_clk` (PLL), operações SPI dependentes de CSR não são garantidas. Protocolo operacional precisa exigir PLL travado, ou haver domínio always-on.
6. `aes_done`, `aes_error`, `aes_busy`, `pll_locked` e `power_state` devem estar estáveis/sincronizados no domínio sys_clk; o top não faz CDC deles.
7. O mecanismo de prefetch não resolve atomicidade global de vários CSRs: cada leitura captura um CSR no instante de atendimento do request. Status read-to-clear não foi implementado.
8. **Limitação didática:** se uma nova transação chegar enquanto houver mailbox ocupado, a solicitação poderá ser rejeitada e sinalizada por `spi_error`. Sistemas reais precisam definir tempo mínimo entre transações ou buffering adequado.

## Validação e Simulação
- **Lint / Verificação de Sintaxe (Synopsys VCS `vlogan`):**
  ```bash
  make lint
  ```
- **Simulação Completa do Subsistema SPI (Synopsys VCS):**
  ```bash
  make sim_spi
  ```
- **Simulação via Icarus Verilog (opcional):**
  ```bash
  iverilog -g2012 -s tb_spi_aes_top -o sim rtl/spi_pkg.sv rtl/spi_if.sv rtl/*.sv tb/tb_spi_aes_top.sv && vvp sim
  ```

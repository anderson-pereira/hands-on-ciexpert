//=============================================================================
// Project:     Hands-on CIExpert — RTL Design Track
// Module:      spi_aes_top
// Description: Top-level integration of the SPI Peripheral subsystem, CDC,
//              and CSR bank. Uses spi_pkg and SystemVerilog interfaces
//              (spi_phy_if and spi_csr_if) for modular, clean, and robust
//              connectivity.
//=============================================================================

module spi_aes_top import spi_pkg::*; (
    input  logic         rst_n,
    input  logic         sys_clk,
    input  logic         sclk,
    input  logic         cs_n,
    input  logic         pico,
    output logic         poci_o,
    output logic         poci_oe,

    // Status from system blocks
    input  logic         aes_busy,
    input  logic         aes_done,
    input  logic         aes_error,
    input  logic         pll_locked,
    input  logic [1:0]   power_state,

    // Commands and controls for AES and Memory
    output logic         aes_start_pulse,
    output logic [7:0]   aes_config,
    output logic [7:0]   aes_ctrl,
    output logic [127:0] aes_key,
    output logic [15:0]  mem_src_addr,
    output logic [15:0]  mem_dst_addr,
    output logic [7:0]   mem_block_len,

    // PLL and Power configurations / status
    output logic [7:0]   pll_config,
    output logic [7:0]   power_ctrl,
    output logic [7:0]   irq_status,
    output logic         spi_error
);

    // SystemVerilog Interface Instances
    spi_phy_if phy_if();
    spi_csr_if csr_if();

    // Connect external physical pins to PHY interface
    assign phy_if.cs_n   = cs_n;
    assign phy_if.sclk   = sclk;
    assign phy_if.pico   = pico;
    assign poci_o        = phy_if.poci_o;
    assign poci_oe       = phy_if.poci_oe;

    // Mailbox CDC Interfaces (typed for Write and Read channels)
    spi_mb_src_if #(spi_wr_req_t, logic)        wr_mb_src();
    spi_mb_dst_if #(spi_wr_req_t, logic)        wr_mb_dst();

    spi_mb_src_if #(spi_rd_req_t, spi_rd_rsp_t) rd_mb_src();
    spi_mb_dst_if #(spi_rd_req_t, spi_rd_rsp_t) rd_mb_dst();

    // 1. SPI Physical Layer (PHY) in sclk domain (reset by CS_n)
    spi_peripheral_phy u_phy (
        .phy_if(phy_if.peripheral),
        .wr_mb(wr_mb_src.initiator),
        .rd_mb(rd_mb_src.initiator),
        .error(spi_error)
    );

    // 2. Write CDC Mailbox (sclk -> sys_clk)
    spi_cdc_mailbox #(
        .REQ_T(spi_wr_req_t),
        .RSP_T(logic)
    ) u_write_cdc (
        .rst_n,
        .src_clk(sclk),
        .src_if(wr_mb_src.target),
        .dst_clk(sys_clk),
        .dst_if(wr_mb_dst.initiator)
    );

    assign csr_if.wr_valid = wr_mb_dst.valid;
    assign csr_if.wr_addr  = wr_mb_dst.req.addr;
    assign csr_if.wr_data  = wr_mb_dst.req.data;
    assign wr_mb_dst.rsp   = 1'b0;

    // 3. Read CDC Mailbox (sclk <-> sys_clk)
    spi_cdc_mailbox #(
        .REQ_T(spi_rd_req_t),
        .RSP_T(spi_rd_rsp_t)
    ) u_read_cdc (
        .rst_n,
        .src_clk(sclk),
        .src_if(rd_mb_src.target),
        .dst_clk(sys_clk),
        .dst_if(rd_mb_dst.initiator)
    );

    assign csr_if.rd_addr = rd_mb_dst.req.addr;
    assign rd_mb_dst.rsp  = '{data: csr_if.rd_data};

    // 4. CSR Register Bank in sys_clk domain connected via spi_csr_if
    spi_csr_bank u_csrs (
        .sys_clk,
        .rst_n,
        .csr_if(csr_if.target),
        .aes_busy,
        .aes_done,
        .aes_error,
        .pll_locked,
        .power_state,
        .aes_start_pulse,
        .aes_config,
        .aes_ctrl,
        .aes_key,
        .mem_src_addr,
        .mem_dst_addr,
        .mem_block_len,
        .pll_config,
        .power_ctrl,
        .irq_status
    );

endmodule

//=============================================================================
// Project:     Hands-on CIExpert — RTL Design Track
// Module:      spi_cdc_mailbox
// Description: Asynchronous Clock Domain Crossing (CDC) bridge using a 4-phase
//              toggle handshake with static bus Data-Hold protocol.
//              Encapsulated via spi_mb_src_if and spi_mb_dst_if interfaces.
//=============================================================================

module spi_cdc_mailbox #(
    type REQ_T = logic [7:0],
    type RSP_T = logic [7:0]
)(
    input  logic                 rst_n,

    // Source Domain (src_clk)
    input  logic                 src_clk,
    spi_mb_src_if.target         src_if,

    // Destination Domain (dst_clk)
    input  logic                 dst_clk,
    spi_mb_dst_if.initiator      dst_if
);

    REQ_T req_hold;
    RSP_T rsp_hold;

    logic req_toggle, ack_toggle;

    // 2-FF synchronizers (STA constraints defined in SDC via set_clock_groups)
    logic ack_meta, ack_sync;
    logic req_meta, req_sync;

    logic req_seen;
    logic ack_seen;

    assign src_if.ready = (req_toggle == ack_sync);
    assign dst_if.req   = req_hold;

    //-------------------------------------------------------------------------
    // Source Domain Logic (src_clk)
    //-------------------------------------------------------------------------
    always_ff @(posedge src_clk or negedge rst_n) begin
        if (!rst_n) begin
            req_toggle  <= 1'b0;
            req_hold    <= '0;
            ack_meta    <= 1'b0;
            ack_sync    <= 1'b0;
            ack_seen    <= 1'b0;
            src_if.done <= 1'b0;
            src_if.rsp  <= '0;
        end else begin
            // 2-FF synchronizer chain for acknowledge signal
            ack_meta    <= ack_toggle;
            ack_sync    <= ack_meta;
            src_if.done <= 1'b0;

            if (ack_sync != ack_seen) begin
                src_if.rsp  <= rsp_hold;
                src_if.done <= 1'b1;
                ack_seen    <= ack_sync;
            end

            if (src_if.send && src_if.ready) begin
                req_hold   <= src_if.req;
                req_toggle <= ~req_toggle;
            end
        end
    end

    //-------------------------------------------------------------------------
    // Destination Domain Logic (dst_clk)
    //-------------------------------------------------------------------------
    always_ff @(posedge dst_clk or negedge rst_n) begin
        if (!rst_n) begin
            req_meta     <= 1'b0;
            req_sync     <= 1'b0;
            req_seen     <= 1'b0;
            ack_toggle   <= 1'b0;
            dst_if.valid <= 1'b0;
            rsp_hold     <= '0;
        end else begin
            // 2-FF synchronizer chain for request signal
            req_meta     <= req_toggle;
            req_sync     <= req_meta;
            dst_if.valid <= 1'b0;

            if (req_sync != req_seen) begin
                req_seen     <= req_sync;
                dst_if.valid <= 1'b1;
                rsp_hold     <= dst_if.rsp;
                ack_toggle   <= req_sync;
            end
        end
    end

endmodule

//=============================================================================
// Project:     Hands-on CIExpert — RTL Design Track
// Module:      spi_csr_bank
// Description: Control and Status Register (CSR) bank in the sys_clk domain.
//              Uses spi_pkg (address constants) and the spi_csr_if interface
//              with 'target' modport.
//=============================================================================

module spi_csr_bank import spi_pkg::*; (
    input  logic         sys_clk,
    input  logic         rst_n,

    // CSR Bus Interface (Target Modport)
    spi_csr_if.target    csr_if,

    // System Blocks Status
    input  logic         aes_busy,
    input  logic         aes_done,
    input  logic         aes_error,
    input  logic         pll_locked,
    input  logic [1:0]   power_state,

    // Commands and Controls to AES Core
    output logic         aes_start_pulse,
    output logic [7:0]   aes_config,
    output logic [7:0]   aes_ctrl,
    output logic [127:0] aes_key,

    // Parameters for Memory / DMA Subsystem
    output logic [15:0]  mem_src_addr,
    output logic [15:0]  mem_dst_addr,
    output logic [7:0]   mem_block_len,

    // PLL and Power Configuration / Status
    output logic [7:0]   pll_config,
    output logic [7:0]   power_ctrl,
    output logic [7:0]   irq_status
);

    // Internal registers
    logic [7:0]  key_mem [0:15];
    logic [7:0]  block_len_reg;
    logic [15:0] src_addr_reg;
    logic [15:0] dst_addr_reg;

    assign mem_block_len = block_len_reg;
    assign mem_src_addr  = src_addr_reg;
    assign mem_dst_addr  = dst_addr_reg;

    // Continuous concatenation for the 128-bit key
    assign aes_key = {
        key_mem[0],  key_mem[1],  key_mem[2],  key_mem[3],
        key_mem[4],  key_mem[5],  key_mem[6],  key_mem[7],
        key_mem[8],  key_mem[9],  key_mem[10], key_mem[11],
        key_mem[12], key_mem[13], key_mem[14], key_mem[15]
    };

    // Synchronous write to registers
    always_ff @(posedge sys_clk or negedge rst_n) begin
        if (!rst_n) begin
            aes_ctrl        <= 8'h00;
            aes_config      <= 8'h00;
            pll_config      <= 8'h00;
            power_ctrl      <= 8'h00;
            irq_status      <= 8'h00;
            block_len_reg   <= 8'h01; // Default: 1 block
            src_addr_reg    <= 16'h0000;
            dst_addr_reg    <= 16'h0000;
            aes_start_pulse <= 1'b0;
            for (int i = 0; i < 16; i++) begin
                key_mem[i] <= 8'h00;
            end
        end else begin
            aes_start_pulse <= 1'b0;

            if (csr_if.wr_valid) begin
                case (csr_if.wr_addr)
                    ADDR_AES_CTRL: begin
                        aes_ctrl        <= {csr_if.wr_data[7:1], 1'b0};
                        aes_start_pulse <= csr_if.wr_data[0];
                    end
                    ADDR_AES_CONFIG: begin
                        aes_config <= csr_if.wr_data;
                    end
                    ADDR_BLOCK_LEN: begin
                        block_len_reg <= csr_if.wr_data;
                    end
                    ADDR_SRC_ADDR_L: begin
                        src_addr_reg[7:0] <= csr_if.wr_data;
                    end
                    ADDR_SRC_ADDR_H: begin
                        src_addr_reg[15:8] <= csr_if.wr_data;
                    end
                    ADDR_DST_ADDR_L: begin
                        dst_addr_reg[7:0] <= csr_if.wr_data;
                    end
                    ADDR_DST_ADDR_H: begin
                        dst_addr_reg[15:8] <= csr_if.wr_data;
                    end
                    // 128-bit AES Key (0x10 to 0x1F)
                    7'h10, 7'h11, 7'h12, 7'h13, 7'h14, 7'h15, 7'h16, 7'h17,
                    7'h18, 7'h19, 7'h1a, 7'h1b, 7'h1c, 7'h1d, 7'h1e, 7'h1f: begin
                        key_mem[csr_if.wr_addr[3:0]] <= csr_if.wr_data;
                    end
                    // PLL write protection: Ignored if !pll_locked
                    ADDR_PLL_CONFIG: begin
                        if (pll_locked) begin
                            pll_config <= csr_if.wr_data;
                        end
                    end
                    ADDR_POWER_CTRL: begin
                        power_ctrl <= csr_if.wr_data;
                    end
                    default: begin end
                endcase
            end

            // IRQ status handling (Write-1-to-Clear)
            if (csr_if.wr_valid && csr_if.wr_addr == ADDR_IRQ_STATUS) begin
                irq_status <= (irq_status & ~csr_if.wr_data) | {6'b0, aes_error, aes_done};
            end else begin
                irq_status <= irq_status | {6'b0, aes_error, aes_done};
            end
        end
    end

    // Combinational register read multiplexer
    always_comb begin
        csr_if.rd_data = 8'h00;
        case (csr_if.rd_addr)
            ADDR_AES_CTRL:     csr_if.rd_data = aes_ctrl;
            ADDR_AES_STATUS:   csr_if.rd_data = {5'b0, aes_error, aes_done, aes_busy};
            ADDR_AES_CONFIG:   csr_if.rd_data = aes_config;
            ADDR_IRQ_STATUS:   csr_if.rd_data = irq_status;
            ADDR_BLOCK_LEN:    csr_if.rd_data = block_len_reg;
            ADDR_SRC_ADDR_L:   csr_if.rd_data = src_addr_reg[7:0];
            ADDR_SRC_ADDR_H:   csr_if.rd_data = src_addr_reg[15:8];
            ADDR_DST_ADDR_L:   csr_if.rd_data = dst_addr_reg[7:0];
            ADDR_DST_ADDR_H:   csr_if.rd_data = dst_addr_reg[15:8];
            7'h10, 7'h11, 7'h12, 7'h13, 7'h14, 7'h15, 7'h16, 7'h17,
            7'h18, 7'h19, 7'h1a, 7'h1b, 7'h1c, 7'h1d, 7'h1e, 7'h1f: begin
                csr_if.rd_data = key_mem[csr_if.rd_addr[3:0]];
            end
            ADDR_PLL_CONFIG:   csr_if.rd_data = pll_config;
            ADDR_PLL_STATUS:   csr_if.rd_data = {7'b0, pll_locked};
            ADDR_POWER_CTRL:   csr_if.rd_data = power_ctrl;
            ADDR_POWER_STATUS: csr_if.rd_data = {6'b0, power_state};
            default:           csr_if.rd_data = 8'h00;
        endcase
    end

endmodule

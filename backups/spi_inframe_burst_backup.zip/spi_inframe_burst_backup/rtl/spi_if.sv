//=============================================================================
// Project:     Hands-on CIExpert — RTL Design Track
// Interfaces:  spi_phy_if and spi_csr_if
// Description: SystemVerilog interface encapsulation using modern terminology
//              (PICO / POCI, Controller / Peripheral, Initiator / Target).
//=============================================================================

//-----------------------------------------------------------------------------
// Physical SPI Bus Interface (Mode 0)
// Signals:
//   cs_n    : Chip Select (active low)
//   sclk    : Serial Clock
//   pico    : Peripheral In, Controller Out (formerly MOSI)
//   poci_o  : Peripheral Out, Controller In (data output)
//   poci_oe : Peripheral Out Output Enable (for tri-state driver)
//-----------------------------------------------------------------------------
interface spi_phy_if;
    logic cs_n;
    logic sclk;
    logic pico;
    logic poci_o;
    logic poci_oe;

    // Modport for the peripheral device (SPI Peripheral PHY)
    modport peripheral (
        input  cs_n,
        input  sclk,
        input  pico,
        output poci_o,
        output poci_oe
    );

    // Modport for the controller / testbench host
    modport controller (
        output cs_n,
        output sclk,
        output pico,
        input  poci_o,
        input  poci_oe
    );
endinterface : spi_phy_if


//-----------------------------------------------------------------------------
// Internal Synchronous CSR Bus Interface (sys_clk domain)
//-----------------------------------------------------------------------------
interface spi_csr_if;
    logic       wr_valid;
    logic [6:0] wr_addr;
    logic [7:0] wr_data;
    logic [6:0] rd_addr;
    logic [7:0] rd_data;

    // Modport for the bus bridge initiator (CDC Mailbox)
    modport initiator (
        output wr_valid,
        output wr_addr,
        output wr_data,
        output rd_addr,
        input  rd_data
    );

    // Modport for the register bank target (CSR Bank)
    modport target (
        input  wr_valid,
        input  wr_addr,
        input  wr_data,
        input  rd_addr,
        output rd_data
    );
endinterface : spi_csr_if


//-----------------------------------------------------------------------------
// Mailbox CDC Source-Domain Interface (src_clk domain, e.g. sclk)
// Connects the request initiator (PHY) to the CDC mailbox bridge.
//-----------------------------------------------------------------------------
interface spi_mb_src_if #(
    type REQ_T = logic [7:0],
    type RSP_T = logic [7:0]
);
    logic send;
    REQ_T req;
    logic ready;
    logic done;
    RSP_T rsp;

    // Modport for the transaction initiator (PHY)
    modport initiator (
        output send,
        output req,
        input  ready,
        input  done,
        input  rsp
    );

    // Modport for the CDC bridge target (Mailbox)
    modport target (
        input  send,
        input  req,
        output ready,
        output done,
        output rsp
    );
endinterface : spi_mb_src_if


//-----------------------------------------------------------------------------
// Mailbox CDC Destination-Domain Interface (dst_clk domain, e.g. sys_clk)
// Connects the CDC mailbox bridge to the destination consumer / CSR bus.
//-----------------------------------------------------------------------------
interface spi_mb_dst_if #(
    type REQ_T = logic [7:0],
    type RSP_T = logic [7:0]
);
    logic valid;
    REQ_T req;
    RSP_T rsp;

    // Modport for the CDC bridge initiator (Mailbox)
    modport initiator (
        output valid,
        output req,
        input  rsp
    );

    // Modport for the destination target / consumer
    modport target (
        input  valid,
        input  req,
        output rsp
    );
endinterface : spi_mb_dst_if


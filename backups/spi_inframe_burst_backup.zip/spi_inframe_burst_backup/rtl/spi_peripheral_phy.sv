//=============================================================================
// Project:     Hands-on CIExpert — RTL Design Track
// Module:      spi_peripheral_phy
// Description: Physical Layer (PHY) of the SPI Peripheral (Mode 0, MSB-first,
//              active-low CS_n). Uses spi_pkg (packed structs for CDC) and
//              the spi_phy_if interface with 'peripheral' modport.
//              Uses modern PICO (Peripheral In, Controller Out) and
//              POCI (Peripheral Out, Controller In) signal terminology.
//=============================================================================

module spi_peripheral_phy import spi_pkg::*; (
    // Physical SPI Bus Interface (Peripheral Modport)
    spi_phy_if.peripheral   phy_if,

    // CDC Mailbox Interfaces (sclk domain)
    spi_mb_src_if.initiator wr_mb,
    spi_mb_src_if.initiator rd_mb,

    // Frame-level protocol/timing diagnostic error flag
    output logic            error
);

    spi_phy_state_e state;

    logic [2:0] bit_idx;
    logic [7:0] rx_shift;
    logic [6:0] address;
    logic [7:0] active_data, next_data;
    logic       active_valid, next_valid;
    logic       expect_response;
    logic       poci_ff;
    logic [7:0] received;

    // Asynchronous frame reset: controlled purely by CS_n (active when cs_n=1)
    wire phy_rst_n = !phy_if.cs_n;

    assign received = {rx_shift[6:0], phy_if.pico};

    // Physical bus signal assignments
    assign phy_if.poci_o  = poci_ff;
    assign phy_if.poci_oe = (!phy_if.cs_n && state == SPI_STATE_READ);

    // Combinational logic for CDC requests
    always_comb begin
        wr_mb.req.addr = address;
        wr_mb.req.data = received;
        wr_mb.send     = !phy_if.cs_n && state == SPI_STATE_WRITE && bit_idx == 3'd7
                         && address != ADDR_RESERVED && wr_mb.ready;

        rd_mb.req.addr = address;
        rd_mb.send     = 1'b0;

        if (!phy_if.cs_n && state == SPI_STATE_CMD && bit_idx == 3'd7 && received[7]
            && received[6:0] != ADDR_RESERVED && rd_mb.ready) begin
            rd_mb.req.addr = received[6:0];
            rd_mb.send     = 1'b1;
        end else if (!phy_if.cs_n && state == SPI_STATE_READ && bit_idx == 3'd0
                     && address != 7'h7f && rd_mb.ready && !expect_response) begin
            rd_mb.req.addr = address + 7'd1;
            rd_mb.send     = 1'b1;
        end
    end

    // Protocol/timing error flag for the active frame (reset by phy_rst_n)
    always_ff @(posedge phy_if.sclk or negedge phy_rst_n) begin
        if (!phy_rst_n) begin
            error <= 1'b0;
        end else begin
            if (bit_idx == 3'd7) begin
                case (state)
                    SPI_STATE_CMD: begin
                        if (received[7] && received[6:0] != ADDR_RESERVED && !rd_mb.ready)
                            error <= 1'b1;
                    end
                    SPI_STATE_WRITE: begin
                        if (address != ADDR_RESERVED && !wr_mb.ready)
                            error <= 1'b1;
                    end
                    SPI_STATE_DUMMY: begin
                        if (!next_valid && !(rd_mb.done && expect_response) && address != ADDR_RESERVED)
                            error <= 1'b1;
                    end
                    SPI_STATE_READ: begin
                        if (!next_valid && !(rd_mb.done && expect_response))
                            error <= 1'b1;
                    end
                    default: begin end
                endcase
            end
            if (state == SPI_STATE_READ && bit_idx == 3'd0 && address != 7'h7f) begin
                if (!rd_mb.ready || expect_response)
                    error <= 1'b1;
            end
        end
    end

    // Serial transaction state registers (reset by phy_rst_n)
    always_ff @(posedge phy_if.sclk or negedge phy_rst_n) begin
        if (!phy_rst_n) begin
            state           <= SPI_STATE_CMD;
            bit_idx         <= 3'd0;
            rx_shift        <= 8'd0;
            address         <= 7'd0;
            active_data     <= 8'd0;
            next_data       <= 8'd0;
            active_valid    <= 1'b0;
            next_valid      <= 1'b0;
            expect_response <= 1'b0;
        end else begin
            rx_shift <= received;
            bit_idx  <= bit_idx + 1'b1;

            if (rd_mb.done && expect_response) begin
                next_data       <= rd_mb.rsp.data;
                next_valid      <= 1'b1;
                expect_response <= 1'b0;
            end

            if (bit_idx == 3'd7) begin
                case (state)
                    SPI_STATE_CMD: begin
                        address <= received[6:0];
                        if (received[7]) begin
                            state <= SPI_STATE_DUMMY;
                            if (received[6:0] != ADDR_RESERVED && rd_mb.ready) begin
                                expect_response <= 1'b1;
                            end
                        end else begin
                            state <= SPI_STATE_WRITE;
                        end
                    end

                    SPI_STATE_WRITE: begin
                        if (address != 7'h7f) begin
                            address <= address + 1'b1;
                        end
                    end

                    SPI_STATE_DUMMY: begin
                        state <= SPI_STATE_READ;
                        if (next_valid) begin
                            active_data  <= next_data;
                            active_valid <= 1'b1;
                            next_valid   <= 1'b0;
                        end else if (rd_mb.done && expect_response) begin
                            active_data     <= rd_mb.rsp.data;
                            active_valid    <= 1'b1;
                            expect_response <= 1'b0;
                        end else begin
                            active_data  <= 8'h00;
                            active_valid <= 1'b0;
                        end
                    end

                    SPI_STATE_READ: begin
                        if (next_valid) begin
                            active_data  <= next_data;
                            active_valid <= 1'b1;
                            next_valid   <= 1'b0;
                        end else if (rd_mb.done && expect_response) begin
                            active_data     <= rd_mb.rsp.data;
                            active_valid    <= 1'b1;
                            expect_response <= 1'b0;
                        end else begin
                            active_data  <= 8'h00;
                            active_valid <= 1'b0;
                        end
                    end

                    default: state <= SPI_STATE_CMD;
                endcase
            end

            // Prefetch for burst read
            if (state == SPI_STATE_READ && bit_idx == 3'd0) begin
                if (address != 7'h7f) begin
                    address <= address + 1'b1;
                    if (rd_mb.ready && !expect_response) begin
                        expect_response <= 1'b1;
                    end
                end
            end
        end
    end

    // Update POCI on clock falling edge (negedge sclk)
    always_ff @(negedge phy_if.sclk or negedge phy_rst_n) begin
        if (!phy_rst_n) begin
            poci_ff <= 1'b0;
        end else if (state == SPI_STATE_READ && active_valid) begin
            poci_ff <= active_data[7 - bit_idx];
        end else begin
            poci_ff <= 1'b0;
        end
    end

endmodule

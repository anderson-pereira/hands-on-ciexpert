//=============================================================================
// Project:     Hands-on CIExpert — RTL Design Track
// Package:     spi_pkg
// Description: Type definitions, packed structs, FSM states, and CSR address
//              map constants for the SPI Peripheral subsystem and CDC bridge.
//=============================================================================

package spi_pkg;

    //-------------------------------------------------------------------------
    // 1. CSR Address Map Constants (7-bit address: 0x00 to 0x7F)
    //-------------------------------------------------------------------------
    localparam logic [6:0] ADDR_RESERVED     = 7'h00;
    localparam logic [6:0] ADDR_AES_CTRL     = 7'h01;
    localparam logic [6:0] ADDR_AES_STATUS   = 7'h02;
    localparam logic [6:0] ADDR_AES_CONFIG   = 7'h03;
    localparam logic [6:0] ADDR_IRQ_STATUS   = 7'h04;
    localparam logic [6:0] ADDR_BLOCK_LEN    = 7'h05;
    localparam logic [6:0] ADDR_SRC_ADDR_L   = 7'h06;
    localparam logic [6:0] ADDR_SRC_ADDR_H   = 7'h07;
    localparam logic [6:0] ADDR_DST_ADDR_L   = 7'h08;
    localparam logic [6:0] ADDR_DST_ADDR_H   = 7'h09;
    localparam logic [6:0] ADDR_KEY_BASE     = 7'h10; // 0x10 to 0x1F (16 bytes of AES key)
    localparam logic [6:0] ADDR_PLL_CONFIG   = 7'h20;
    localparam logic [6:0] ADDR_PLL_STATUS   = 7'h21;
    localparam logic [6:0] ADDR_POWER_CTRL   = 7'h30;
    localparam logic [6:0] ADDR_POWER_STATUS = 7'h31;

    //-------------------------------------------------------------------------
    // 2. Physical Layer (SPI PHY) FSM States
    //-------------------------------------------------------------------------
    typedef enum logic [1:0] {
        SPI_STATE_CMD   = 2'b00,
        SPI_STATE_WRITE = 2'b01,
        SPI_STATE_DUMMY = 2'b10,
        SPI_STATE_READ  = 2'b11
    } spi_phy_state_e;

    //-------------------------------------------------------------------------
    // 3. Packed Structs for CDC Crossing
    //-------------------------------------------------------------------------

    // Write request packet (PHY -> CSR Bank)
    typedef struct packed {
        logic [6:0] addr;
        logic [7:0] data;
    } spi_wr_req_t; // 15 bits

    // Read request packet (PHY -> CSR Bank)
    typedef struct packed {
        logic [6:0] addr;
    } spi_rd_req_t; // 7 bits

    // Read response packet (CSR Bank -> PHY)
    typedef struct packed {
        logic [7:0] data;
    } spi_rd_rsp_t; // 8 bits

endpackage : spi_pkg

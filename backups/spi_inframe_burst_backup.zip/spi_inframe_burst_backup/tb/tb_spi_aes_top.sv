`timescale 1ns/1ps

module tb_spi_aes_top;
    logic rst_n = 0;
    logic sys_clk = 0;
    logic sclk = 0;
    logic cs_n = 1;
    logic pico = 0;
    wire  poci_o;
    wire  poci_oe;
    wire  poci = poci_oe ? poci_o : 1'bz; // Testbench emulation of physical tri-state line

    logic aes_busy = 0, aes_done = 0, aes_error = 0, pll_locked = 1;
    logic [1:0] power_state = 2'b01;

    wire aes_start_pulse;
    wire [7:0] aes_config, pll_config, power_ctrl, aes_ctrl, irq_status;
    wire [127:0] aes_key;
    wire [15:0] mem_src_addr, mem_dst_addr;
    wire [7:0]  mem_block_len;
    wire spi_error;

    always #2.5 sys_clk = ~sys_clk; // 200 MHz

    spi_aes_top dut (.*);

    // SCLK = 5 MHz, CPOL=0. Samples POCI on positive edge.
    task automatic spi_byte(input logic [7:0] tx, output logic [7:0] rx);
        integer i;
        begin
            rx = 0;
            for (i = 7; i >= 0; i = i - 1) begin
                pico = tx[i];
                #100 sclk = 1;
                rx[i] = poci;
                #100 sclk = 0;
            end
        end
    endtask

    task automatic begin_frame;
        begin
            #100 cs_n = 0;
            #100 begin end
        end
    endtask

    task automatic end_frame;
        begin
            #100 cs_n = 1;
            #1500 begin end // Allow any pending write to commit.
        end
    endtask

    task automatic write_reg(input logic [6:0] addr, input logic [7:0] data);
        logic [7:0] junk;
        begin
            begin_frame();
            spi_byte({1'b0, addr}, junk);
            spi_byte(data, junk);
            end_frame();
        end
    endtask

    task automatic read_reg(input logic [6:0] addr, output logic [7:0] result);
        logic [7:0] junk;
        begin
            begin_frame();
            spi_byte({1'b1, addr}, junk);
            spi_byte(8'h00, junk); // dummy
            spi_byte(8'h00, result);
            end_frame();
        end
    endtask

    logic [7:0] got, junk;

    initial begin
        #50 rst_n = 1;
        #100 begin end

        // 1. Test basic write and read
        write_reg(7'h03, 8'hA5);
        if (aes_config !== 8'hA5) $fatal(1, "AES_CONFIG write failed: %h", aes_config);
        read_reg(7'h03, got);
        if (got !== 8'hA5) $fatal(1, "AES_CONFIG read failed: %h", got);

        // 2. Test PLL lock protection (Must ignore write if pll_locked == 0)
        pll_locked = 0;
        write_reg(7'h20, 8'hEE); // Should be IGNORED
        if (pll_config === 8'hEE) $fatal(1, "ERROR: PLL_CONFIG accepted write while pll_locked == 0!");
        
        pll_locked = 1;
        write_reg(7'h20, 8'h5A); // Now should SUCCEED
        read_reg(7'h20, got);
        if (got !== 8'h5A) $fatal(1, "PLL_CONFIG read failed after locked: %h", got);

        // 3. Test memory pointers and block len
        write_reg(7'h05, 8'h04); // block_len = 4
        write_reg(7'h06, 8'h34); // src_addr_l = 0x34
        write_reg(7'h07, 8'h12); // src_addr_h = 0x12 -> 0x1234
        if (mem_block_len !== 8'h04) $fatal(1, "mem_block_len mismatch: %h", mem_block_len);
        if (mem_src_addr !== 16'h1234) $fatal(1, "mem_src_addr mismatch: %h", mem_src_addr);

        // 4. Test 16-byte burst write to 128-bit Key (0x10 to 0x1F)
        begin_frame();
        spi_byte(8'h10, junk); // Address 0x10, write mode
        for (int b = 0; b < 16; b++) begin
            spi_byte(8'hA0 + b[7:0], junk);
        end
        end_frame();

        // Verify that 128-bit key matches {A0, A1, A2, ..., AF}
        if (aes_key[127:120] !== 8'hA0 || aes_key[7:0] !== 8'hAF) begin
            $fatal(1, "128-bit key burst write failed! aes_key = %h", aes_key);
        end
        $display("[TB] 128-bit AES Key successfully loaded via 16-byte burst write: %h", aes_key);

        // 5. Test 16-byte contiguous burst read from 128-bit Key (0x10 to 0x1F)
        begin_frame();
        spi_byte(8'h90, junk); // Address 0x10, read mode (bit 7 = 1)
        spi_byte(8'h00, junk); // 1 byte Dummy
        for (int b = 0; b < 16; b++) begin
            spi_byte(8'h00, got);
            if (got !== (8'hA0 + b[7:0])) begin
                $fatal(1, "16-byte burst read mismatch at byte %0d (addr 0x%h): expected %h, got %h",
                       b, 7'h10 + b[6:0], 8'hA0 + b[7:0], got);
            end
        end
        end_frame();
        $display("[TB] 128-bit AES Key successfully verified via 16-byte burst read!");

        // 6. Test contiguous read burst across 2 bytes (AES_CONFIG and IRQ_STATUS)
        begin_frame();
        spi_byte(8'h83, junk);
        spi_byte(8'h00, junk);
        spi_byte(8'h00, got);
        if (got !== 8'hA5) $fatal(1, "Burst first byte failed: %h", got);
        spi_byte(8'h00, got);
        if (got !== 8'h00) $fatal(1, "Burst second byte failed: %h", got);
        end_frame();

        // 7. Test Abort corner case during Read Burst
        // Start a read burst, read 2 bytes, and suddenly abort by raising CS_n
        begin_frame();
        spi_byte(8'h90, junk); // Read 0x10
        spi_byte(8'h00, junk); // Dummy
        spi_byte(8'h00, got);  // Read 0x10
        if (got !== 8'hA0) $fatal(1, "Abort test byte 0 mismatch: %h", got);
        spi_byte(8'h00, got);  // Read 0x11
        if (got !== 8'hA1) $fatal(1, "Abort test byte 1 mismatch: %h", got);
        end_frame(); // Abrupt abort while prefetch for 0x12 was in flight!

        // Immediately start a new transaction to confirm clean recovery without stale data
        read_reg(7'h03, got);
        if (got !== 8'hA5) $fatal(1, "Post-abort read failed! Expected 0xA5, got: %h", got);
        $display("[TB] Post-abort transaction recovery verified successfully!");

        // 8. Address zero is reserved
        read_reg(7'h00, got);
        if (got !== 8'h00) $fatal(1, "Reserved addr should read zero");

        if (spi_error) $fatal(1, "ERROR: spi_error was raised during simulation!");
        $display("PASS: All SPI CSR, PLL protection, CDC, 16-byte write/read bursts, and abort recovery completed successfully!");
        $finish;
    end

    initial begin
        #1000000 $fatal(1, "Timeout");
    end
endmodule
